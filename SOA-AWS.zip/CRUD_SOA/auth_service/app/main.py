from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from .database import Base, engine
from .auth import routes as auth_routes
from .auth.dependencies import get_current_user  # ✅ Import correcto
from sqlalchemy.orm import Session

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Auth Service - SOA")

@app.get("/")
def root():
    return {"message": "Auth service is running"}

# ✅ Ruta protegida que usa el token
@app.get("/protected")
def protected_route(current_user: str = Depends(get_current_user)):
    return {"message": f"Bienvenido {current_user}, estás autenticado."}

# Rutas de autenticación
app.include_router(auth_routes.router, prefix="/auth", tags=["auth"])

# Middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8002",  # Swagger UI de products
        "http://localhost:8001",  # si tuvieras otra UI
        "http://localhost:8080"   # frontend (ej. Vue/React)
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# product_service/app/s3_utils.py

import boto3
import os
from botocore.exceptions import NoCredentialsError

def upload_file_to_s3(file, bucket_name, object_name=None):
    """
    Sube un archivo a un bucket de S3.

    :param file: Archivo a subir (desde FastAPI UploadFile).
    :param bucket_name: Bucket a donde subir el archivo.
    :param object_name: Nombre del objeto en S3. Si no se especifica, se usa el nombre del archivo.
    :return: La URL pública del archivo si se subió correctamente, de lo contrario None.
    """
    # Si object_name no se especifica, usa el nombre del archivo original
    if object_name is None:
        object_name = file.filename

    # Crear un cliente de S3
    s3_client = boto3.client(
        's3',
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
        # --- CORRECCIÓN: Se añade el token de sesión para AWS Academy ---
        aws_session_token=os.getenv("AWS_SESSION_TOKEN")
    )

    try:
        # Sube el archivo usando upload_fileobj para manejar archivos en memoria
        s3_client.upload_fileobj(file.file, bucket_name, object_name)

        # Genera la URL pública del archivo
        # Para AWS Academy, la región suele ser us-east-1
        region = "us-east-1" 
        url = f"https://{bucket_name}.s3.{region}.amazonaws.com/{object_name}"
        
        print(f"✅ Archivo subido exitosamente a: {url}")
        return url

    except FileNotFoundError:
        print("❌ El archivo no fue encontrado.")
        return None
    except NoCredentialsError:
        print("❌ Credenciales no encontradas.")
        return None
    except Exception as e:
        print(f"❌ Ocurrió un error al subir el archivo: {e}")
        return None
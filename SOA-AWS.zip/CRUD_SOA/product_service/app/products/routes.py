from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional
import os
import requests
import json

# Importaciones locales de tu proyecto
from . import models, schemas
from ..database import get_db
from .dependencies import get_current_admin
from ..s3_utils import upload_file_to_s3

router = APIRouter()

# -------------------------------
# RUTAS DE PRODUCTOS
# -------------------------------

@router.post("/", response_model=schemas.ProductResponse, status_code=201)
def create_product(
    nombre: str = Form(...),
    plataforma: str = Form(...),
    precio: float = Form(...),
    descripcion: str = Form(...),
    estado: str = Form(...),
    imagen: UploadFile = File(...),
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin)
):
    """
    Crea un nuevo producto, validando la descripción con una función Lambda
    y subiendo la imagen a S3.
    """
    
    # --- PASO DE VALIDACIÓN CON LAMBDA ---
    lambda_url = os.getenv("LAMBDA_VALIDATION_URL")
    if not lambda_url:
        raise HTTPException(status_code=500, detail="La URL de validación de Lambda no está configurada.")
        
    try:
        validation_payload = {"descripcion": descripcion}
        response = requests.post(lambda_url, data=json.dumps(validation_payload))
        
        if response.status_code != 200:
            error_msg = response.json().get("mensaje", "Error de validación desconocido.")
            raise HTTPException(status_code=400, detail=f"Validación fallida: {error_msg}")
            
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=503, detail=f"No se pudo contactar al servicio de validación: {e}")
    # --- FIN DEL PASO DE VALIDACIÓN ---

    # 1. Subir la imagen a S3
    bucket_name = os.getenv("S3_BUCKET_NAME")
    if not bucket_name:
        raise HTTPException(status_code=500, detail="S3_BUCKET_NAME no está configurado.")

    image_url = upload_file_to_s3(imagen, bucket_name, object_name=f"products/{imagen.filename}")
    if not image_url:
        raise HTTPException(status_code=500, detail="Error al subir la imagen a S3.")

    # 2. Crear el objeto Pydantic
    product_data = schemas.ProductCreate(
        nombre=nombre,
        plataforma=plataforma,
        precio=precio,
        descripcion=descripcion,
        estado=estado,
        image_url=image_url
    )
    
    # 3. Guardar en la base de datos
    db_product = models.Product(**product_data.dict())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    
    return db_product

@router.put("/{product_id}", response_model=schemas.ProductResponse)
def update_product(
    product_id: int,
    nombre: str = Form(...),
    plataforma: str = Form(...),
    precio: float = Form(...),
    descripcion: str = Form(...),
    estado: str = Form(...),
    imagen: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin)
):
    db_product = db.query(models.Product).filter(models.Product.id == product_id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")

    # --- CORRECCIÓN: AÑADIR VALIDACIÓN LAMBDA AQUÍ TAMBIÉN ---
    lambda_url = os.getenv("LAMBDA_VALIDATION_URL")
    if not lambda_url:
        raise HTTPException(status_code=500, detail="La URL de validación de Lambda no está configurada.")
        
    try:
        validation_payload = {"descripcion": descripcion}
        response = requests.post(lambda_url, data=json.dumps(validation_payload))
        
        if response.status_code != 200:
            error_msg = response.json().get("mensaje", "Error de validación desconocido.")
            raise HTTPException(status_code=400, detail=f"Validación fallida: {error_msg}")
            
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=503, detail=f"No se pudo contactar al servicio de validación: {e}")
    # --- FIN DE LA CORRECCIÓN ---

    image_url = db_product.image_url

    if imagen:
        bucket_name = os.getenv("S3_BUCKET_NAME")
        if not bucket_name:
            raise HTTPException(status_code=500, detail="S3_BUCKET_NAME no está configurado.")
        
        image_url = upload_file_to_s3(imagen, bucket_name, object_name=f"products/{imagen.filename}")
        if not image_url:
            raise HTTPException(status_code=500, detail="Error al subir la nueva imagen a S3.")

    db_product.nombre = nombre
    db_product.plataforma = plataforma
    db_product.precio = precio
    db_product.descripcion = descripcion
    db_product.estado = estado
    db_product.image_url = image_url

    db.commit()
    db.refresh(db_product)
    return db_product

@router.get("/", response_model=List[schemas.ProductResponse])
def get_products(db: Session = Depends(get_db), admin_user: dict = Depends(get_current_admin)):
    return db.query(models.Product).all()

@router.get("/{product_id}", response_model=schemas.ProductResponse)
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.query(models.Product).filter(models.Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    return product

@router.delete("/{product_id}", status_code=204)
def delete_product(
    product_id: int,
    db: Session = Depends(get_db),
    admin_user: dict = Depends(get_current_admin)
):
    db_product = db.query(models.Product).filter(models.Product.id == product_id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    
    db.delete(db_product)
    db.commit()
    return {"message": "Producto eliminado"}

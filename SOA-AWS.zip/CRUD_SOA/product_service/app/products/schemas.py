from pydantic import BaseModel

class ProductBase(BaseModel):
    nombre: str
    plataforma: str
    precio: float
    descripcion: str
    estado: str
    

class ProductCreate(ProductBase):
    pass

class ProductResponse(ProductBase):
    id: int
    class Config:
        orm_mode = True
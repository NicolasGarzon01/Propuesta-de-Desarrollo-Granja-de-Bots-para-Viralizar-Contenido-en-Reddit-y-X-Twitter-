from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
import requests

# Endpoint de validación en auth_service
AUTH_SERVICE_URL = "http://auth_service:8000/auth/verify-login"

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="http://localhost:8000/auth/login")

def get_current_admin(token: str = Depends(oauth2_scheme)):
    """
    Llama al auth_service para validar el token y confirmar si el usuario es admin.
    """
    print(f"🔐 [DEBUG] Token recibido en product_service: {token}")
    
    try:
        # DEBUG: Mostrar información de la petición
        print(f"🔍 [DEBUG] Enviando petición a: {AUTH_SERVICE_URL}")
        print(f"🔍 [DEBUG] Header Authorization: Bearer {token[:50]}...")  # Primeros 50 chars
        
        response = requests.get(
            AUTH_SERVICE_URL,
            headers={"Authorization": f"Bearer {token}"},
            timeout=5
        )
        
        print(f"🔍 [DEBUG] Status code de auth_service: {response.status_code}")
        print(f"🔍 [DEBUG] Response text: {response.text}")
        
        if response.status_code != 200:
            error_detail = f"Auth service returned {response.status_code}"
            if response.status_code >= 500:
                error_detail += " - Error interno del servidor de autenticación"
            elif response.status_code == 401:
                error_detail += " - Token inválido o expirado"
            elif response.status_code == 403:
                error_detail += " - Acceso denegado"
                
            print(f"❌ [ERROR] {error_detail}")
            raise HTTPException(status_code=401, detail=error_detail)

        data = response.json()
        print(f"✅ [DEBUG] Data recibida del auth_service: {data}")
        
        if data.get("role") != "admin":
            print(f"❌ [ERROR] Rol no es admin: {data.get('role')}")
            raise HTTPException(status_code=403, detail="Acceso denegado: se requiere rol admin")

        print(f"✅ [DEBUG] Usuario autorizado: {data.get('username')} con rol: {data.get('role')}")
        return data

    except requests.exceptions.ConnectionError:
        error_msg = "Error de conexión con auth_service - ¿Está ejecutándose?"
        print(f"❌ [ERROR] {error_msg}")
        raise HTTPException(status_code=500, detail=error_msg)
    except requests.exceptions.Timeout:
        error_msg = "Timeout con auth_service - No responde"
        print(f"❌ [ERROR] {error_msg}")
        raise HTTPException(status_code=500, detail=error_msg)
    except requests.exceptions.RequestException as e:
        error_msg = f"Error en la petición al auth_service: {str(e)}"
        print(f"❌ [ERROR] {error_msg}")
        raise HTTPException(status_code=500, detail=error_msg)
    except Exception as e:
        error_msg = f"Error inesperado: {str(e)}"
        print(f"❌ [ERROR] {error_msg}")
        raise HTTPException(status_code=401, detail=error_msg)
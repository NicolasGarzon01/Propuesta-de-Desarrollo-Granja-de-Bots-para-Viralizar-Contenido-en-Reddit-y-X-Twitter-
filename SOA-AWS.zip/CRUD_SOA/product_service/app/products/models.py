from sqlalchemy import Column, Integer, String, Float
from app.database import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    plataforma = Column(String, nullable=False)  # X o Reddit
    precio = Column(Float, nullable=False)
    descripcion = Column(String, nullable=True)
    estado = Column(String, default="activo")  # activo/inactivo
    image_url = Column(String, nullable=True)
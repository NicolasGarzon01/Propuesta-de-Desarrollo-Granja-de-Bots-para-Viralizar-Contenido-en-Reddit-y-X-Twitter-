from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine
from app.products import routes as product_routes
from fastapi.openapi.utils import get_openapi

# Crear tablas en la BD
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Product Service - SOA")

@app.get("/")
def root():
    return {"message": "Product service is running"}

# Registrar rutas de productos
app.include_router(product_routes.router, prefix="/products", tags=["products"])

# Middleware CORS (para que el frontend pueda conectarse sin problemas)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[ 
        "http://localhost:8002",  # Swagger UI de products
        "http://localhost:8001",  # si tuvieras otra UI
        "http://localhost:8080"   # frontend (ej. Vue/React)
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    # 🔑 Cambiar la URL del login a /auth/login
    openapi_schema["components"]["securitySchemes"] = {
        "OAuth2PasswordBearer": {
            "type": "oauth2",
            "flows": {
                "password": {
                    "tokenUrl": "http://localhost:8000/auth/login",  # 👈 aquí apuntas al auth service
                    "scopes": {},
                }
            },
        }
    }
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
